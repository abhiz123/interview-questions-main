import json

def phrasel_search(P, Queries):
    # Write your solution here
    phrase_list = []

    for p in P:
        split = p.split()
        phrase_list.append(split)

    ans = [[]]

    for q in Queries:
        words = q.split()

        strings = matching_strings(phrase_list,words)
        break

    return ans

def matching_strings(phrase_list,query_words):
    print(phrase_list)
    print(query_words)



    for phrases in phrase_list:
        total_words = len(phrases)
        for phrase_words in p:
            if phrase_words in query_words:
                




if __name__ == "__main__":
    with open('sample.json', 'r') as f:
        sample_data = json.loads(f.read())
        P, Queries = sample_data['phrases'], sample_data['queries']
        returned_ans = phrasel_search(P, Queries)
        print('============= ALL TEST PASSED SUCCESSFULLY ===============')
